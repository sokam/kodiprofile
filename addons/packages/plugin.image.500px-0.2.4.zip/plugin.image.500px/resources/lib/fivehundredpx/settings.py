API_HOST    = 'api.500px.com'
API_VERSION = '/v1'
OAUTH_ROOT  = '/oauth/'
RETRY_COUNT = 1
RETRY_DELAY = 0
ALLOWED_FILE_TYPES = ['image/jpeg']