======================
Specto
======================

About
-----
Mrknow fork of *****


About
-----
The origins of streaming


Attributions
---------------------
- 4orbs theme by Marquerite 
- Clean theme by jokster 
- Embossed theme by jokster  
- GOne theme by jokster 
- Metro theme by rayw1986 


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html