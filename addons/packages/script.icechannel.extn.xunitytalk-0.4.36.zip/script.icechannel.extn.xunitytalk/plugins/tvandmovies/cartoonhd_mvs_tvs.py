'''
    Cartoon HD    
    Copyright (C) 2013 Mikey1234
'''

from entertainment.plugnplay.interfaces import MovieSource
from entertainment.plugnplay.interfaces import TVShowSource
from entertainment.plugnplay import Plugin
from entertainment import common


class cartoonhd(MovieSource,TVShowSource):
    implements = [MovieSource,TVShowSource]
    
    name = "Cartoon HD"
    display_name = "Cartoon HD"
    base_url = 'http://cartoonhd.tv/'
   
    source_enabled_by_default = 'true'

            
    
    def GetFileHosts(self, url, list, lock, message_queue):

        import re
        from entertainment.net import Net
        net = Net(cached=False,user_agent='Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5')
     
     
        content = net.http_GET(url).content
  
        token=re.compile("var tor='(.+?)'").findall(content)[0]        
        match=re.compile('elid="(.+?)"').findall(content)
        id = match[0]


        headers=   {'Accept':'application/json, text/javascript, */*; q=0.01',
                    'Accept-Encoding':'gzip, deflate, sdch',
                    'Accept-Language':'en-US,en;q=0.8',
                    'Host':'www.cartoonhd.tv',
                    'Proxy-Connection':'keep-alive',
                    'Referer':url,
                    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36',
                    'X-Requested-With':'XMLHttpRequest'}

        
        OPTION= re.compile('<option value="(.+?)" data-type="(.+?)">').findall(content)

        
        new_search='http://www.cartoonhd.tv/ajax/embeds.php?action=getMovie&id=%s&token=%s' % (id,token)
        content = net.http_GET(new_search,headers=headers).content

        
        for option , server in OPTION:
            
            if '-' in server:
                quality= server.split('-')[1].strip().upper()
                name= server.split('-')[0].strip().upper()
                if '320P' in quality:
                    quality= 'SD'  
            else:
                quality= 'SD'
                name= server.upper()             

            r = '"%s".+?iframe src="(.+?)"' % option
       
            FINAL_URL  = re.compile(r,re.IGNORECASE).findall(content.replace('\\',''))[0]
            
            if 'mail.ru' in FINAL_URL:
                matchme=re.compile('"metadataUrl":"(.+?)"').findall(net.http_GET(FINAL_URL).content)[0]
                quality,url=self.GrabMailRu(matchme,list)
    
            else:
            
                self.AddFileHost(list, quality, FINAL_URL.split('"')[0],host=name)
        
        
        
                
    def GetFileHostsForContent(self, title, name, year, season, episode, type, list, lock, message_queue):                 
        
        from entertainment.net import Net
        import re
        net = Net(cached=False,user_agent='Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5')
        name = self.CleanTextForSearch(name)
        import urllib

        
        token=re.compile("var tor='(.+?)'").findall(net.http_GET('http://www.cartoonhd.tv/').content)[0]
        import time

        unix = int(time.time())

       

        main_url='http://www.cartoonhd.tv/ajax/search.php?q=%s&limit=100&timestamp=%s&verifiedCheck=%s' %(name.replace(' ','%20'),str(unix),token)

  
        content=net.http_GET(main_url).content

        import json

        link=json.loads(content)
        
        for field in link:
          title=field['title'].strip()
          URL=field['permalink'].strip()
          if name.lower() == title.lower():
              if type == 'tv_episodes':
                name=name.lower()
                item_url = '%s/season/%s/episode/%s' %(URL,season,episode)
              else:
                item_url = URL
                
              self.GetFileHosts(item_url, list, lock, message_queue)
              

    def GrabMailRu(self,url,list):
        print 'RESOLVING VIDEO.MAIL.RU VIDEO API LINK'
        
        from entertainment.net import Net
        net = Net(cached=False)

        
        import json,re
        items = []

        data = net.http_GET(url).content
        cookie = net.get_cookies()
        for x in cookie:

             for y in cookie[x]:

                  for z in cookie[x][y]:
                       
                       l= (cookie[x][y][z])
                       
        r = '"key":"(.+?)","url":"(.+?)"'
        match = re.compile(r,re.DOTALL).findall(data)
        for quality,stream in match:
            test = str(l)
            test = test.replace('<Cookie ','')
            test = test.replace(' for .my.mail.ru/>','')
            url=stream +'|Cookie='+test
            QUALITY=quality.upper()
            self.AddFileHost(list, QUALITY, url,host='MAIL.RU')  

             

    def Resolve(self, url):                 

        if 'mail.ru' in url:
            resolved = url
        if 'googleusercontent.com' in url:
            import urllib
            page = urllib.urlopen(url)
            resolved=page.geturl()
            
        elif 'googlevideo.com' in url:
            resolved =url
        else:
        
            from entertainment import istream
            resolved =istream.ResolveUrl(url)
        return resolved    









            
