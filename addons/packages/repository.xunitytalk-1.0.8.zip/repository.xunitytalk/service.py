import urllib , urllib2 , sys , re , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os
oo000 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , '' ) )
repoxml = os . path . join ( oo000 , 'repository.xunitytalk' , 'addon.xml' )
service = os . path . join ( oo000 , 'repository.xunitytalk' , 'service.py' )


from random import randint
VISITOR = str ( randint ( 0 , 0x7fffffff ) )
    
def send_request_to_google_analytics(utm_url):
    ua='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    import urllib2
    try:
        req = urllib2.Request(utm_url, None,
                                    {'User-Agent':ua}
                                     )
        response = urllib2.urlopen(req).read()
    except:
        print ("GA fail: %s" % utm_url)         
    return response
       
def GA(group,name):
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            import time
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            VERSION = "0.0.1"
            
            PATH = "XUNITY" #<---------------------------------           
            UATRACK="UA-69626152-1"#<-------------------------------
            website = "http://xty.me"  #<-----------------------       
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + VERSION + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", "1", VISITOR, "1", "1","2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + VERSION + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", "1", VISITOR, "1", "1","2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + VERSION + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", "1", VISITOR, "1", "1","2"])
                                
            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)
            
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + VERSION + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmhn=" + quote(website) + \
                            "&utmt=" + "events" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", "1", "1", VISITOR,"1","2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================" 

        except:
            print "================  CANNOT POST TO ANALYTICS  ================"

def email():
    search_entered = ''
    keyboard = xbmc.Keyboard(search_entered, 'Enter Email')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText()
    return search_entered   
            
def O0 ( heading , text ) :
 id = 10147
 if 70 - 70: oo0 . O0OO0O0O - oooo
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 100 )
 if 11 - 11: ii1I - ooO0OO000o
 ii11i = xbmcgui . Window ( id )
 if 66 - 66: iIiI * iIiiiI1IiI1I1 * o0OoOoOO00
 I11i = 50
 while ( I11i > 0 ) :
  try :
   xbmc . sleep ( 10 )
   I11i -= 1
   ii11i . getControl ( 1 ) . setLabel ( heading )
   ii11i . getControl ( 5 ) . setText ( text )
   return
  except :
   pass




i1i1II = '''[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk will soon be releasing a new first VIP/Premium Repository...\n\n[COLOR green]Which Will Include:[/COLOR]\n\n Constant updates on all your favorite plugins From Cartoon HD to TV Player and of course [COLOR blue]i[/COLOR]Stream,\n\n\nTo register your interest and Subscribe onto our mailing list to recieve information and updates on how to get onto our premium repository please enter your email when you close this window\n\nThis is When all the fun comes back to Kodi !!\n\n\n[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk'''

O0 ( '[COLOR blue]X[/COLOR]unity[COLOR blue]T[/COLOR]alk Repository' , i1i1II )

I11i = 50
while xbmc . getCondVisibility ( 'Window.IsActive(10147)' ) :
 try : p
 except : pass
dialog = xbmcgui . Dialog ( )
if dialog . yesno ( "Xunity" , "" , "To Get More Information" , 'Please Enter Your Email ?' , 'YES' , 'NO' ) :
    GA('SUBSCRIBED','NO')
else:
    email = email()
    name = email.split('@')[0]
    import random
    age = random.randrange(18,55)

    mailchimp= 'http://xunity.us12.list-manage.com/subscribe/post?u=ca0028600eee5225500b613f2&id=15661a5fd3&MERGE1=%s&MERGE3=%s&MERGE0=%s&b_ca0028600eee5225500b613f2_15661a5fd3=&submit=Subscribe' % (name,str(age),email)
    send_request_to_google_analytics(mailchimp)
    GA('SUBSCRIBED','YES')
    dialog . ok( "Xunity" , "Please Check Your Emails" , "Dont Forget To Check Your Email Junk Folder" , 'You Will Need To Validate Your Email Address' )
    
a=open(repoxml).read()
f= open ( repoxml , mode = 'w' )
f . write ( a.replace('<extension point="xbmc.service" library="service.py" start="login" />','') )
xbmc . executebuiltin ( 'UpdateAddonRepos' )

    
os.remove(service)


