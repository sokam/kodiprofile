import urllib , urllib2 , sys , re , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os , base64 , json , urlresolver
import traceback , string
import random , time
from lib import jsunpack
from urlparse import urlparse
from addon . common . addon import Addon
from addon . common . net import Net
oo000 = Net ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
oooo = xbmcaddon . Addon ( id = 'plugin.video.vdubt' )
iIIii1IIi = 'plugin.video.vdubt'
if 73 - 73: II111iiii
try :
 import StorageServer
except Exception , IiII1IiiIiI1 :
 import storageserverdummy as StorageServer
iIiiiI1IiI1I1 = StorageServer . StorageServer ( iIIii1IIi )
if 87 - 87: OoOoOO00
I11i = Addon ( iIIii1IIi , sys . argv )
O0O = I11i . get_profile ( )
if 78 - 78: i11ii11iIi11i . oOoO0oo0OOOo + IiiI / Iii1ii1II11i
iI111iI = os . path . join ( O0O , 'cookies' )
IiII = os . path . join ( iI111iI , "cookiejar.lwp" )
if os . path . exists ( iI111iI ) == False :
 os . makedirs ( iI111iI )
 if 28 - 28: Ii11111i * iiI1i1
i1I1ii1II1iII = ''
def oooO0oo0oOOOO ( i , t1 , t2 = [ ] ) :
 O0oO = i1I1ii1II1iII
 for o0oO0 in t1 :
  O0oO += chr ( o0oO0 )
  i += 1
  if i > 1 :
   O0oO = O0oO [ : - 1 ]
   i = 0
 for o0oO0 in t2 :
  O0oO += chr ( o0oO0 )
  i += 1
  if i > 1 :
   O0oO = O0oO [ : - 1 ]
   i = 0
 return O0oO
 if 100 - 100: i11Ii11I1Ii1i
 if 67 - 67: iiI1iIiI . ooo0Oo0 * i1 - Oooo0000 * i1IIi11111i / o000o0o00o0Oo
 if 80 - 80: i1iII1I1i1i1 . i1iIIII
def I1 ( ) :
 if 54 - 54: ooo0Oo0 % o0o00Oo0O + oOoO0oo0OOOo - i1IIi11111i / i1
 iIiiI1 = OoOooOOOO ( 'http://pastebin.com/raw.php?i=D1mC4Fb5' )
 if 45 - 45: i1iII1I1i1i1 + Oooo0000
 iII111ii = base64 . b64decode ( iIiiI1 )
 i1iIIi1 = base64 . b64decode ( iII111ii )
 ii11iIi1I = re . compile ( oooO0oo0oOOOO ( 873 , [ 100 , 71 , 5 , 69 , 173 , 78 ] , [ 95 , 82 , 69 , 69 , 77 , 44 , 168 , 32 , 166 , 40 , 156 , 46 , 139 , 43 , 190 , 63 , 24 , 41 , 106 , 10 ] ) ) . findall ( i1iIIi1 )
 if 6 - 6: Ii11111i * i1IIi11111i
 for O00O0O0O0 in ii11iIi1I :
  if 75 - 75: OoOoOO00 / Oooo0000 - iiI1i1
  oo ( O00O0O0O0 . strip ( ) , O00O0O0O0 , 1 , '' , '' )
  if 28 - 28: iI11I1II1I1I - OoOoOO00
 OO ( 'movies' , 'default' )
 if 55 - 55: Iii1ii1II11i / i11Ii11I1Ii1i * ooo0Oo0
 if 86 - 86: Ii + Oooo0000 + i1iIIII * i1 + iiI1i1
 if 61 - 61: Iii1ii1II11i / Ii
def IiIiIi ( url ) :
 if 40 - 40: iiI1iIiI . Ii11111i . IiiI . OoOoOO00
 if 33 - 33: Oooo0000 + i11ii11iIi11i % Ii . i1iIIII - oOoO0oo0OOOo
 iIiiI1 = OoOooOOOO ( 'https://pastebin.com/raw.php?i=D1mC4Fb5' )
 iII111ii = base64 . b64decode ( iIiiI1 )
 i1iIIi1 = base64 . b64decode ( iII111ii )
 O00oooo0O = i1iIIi1 . split ( url ) [ 1 ]
 if 22 - 22: II111iiii % i1 - i1IIi11111i . iI11I1II1I1I * Ii
 II1i1Ii11Ii11 = O00oooo0O . split ( '@@@@@' ) [ 0 ]
 ii11iIi1I = re . compile ( oooO0oo0oOOOO ( 368 , [ 159 , 35 , 86 , 40 ] , [ 214 , 46 , 169 , 43 , 99 , 63 , 45 , 41 , 5 , 44 , 104 , 40 , 135 , 46 , 173 , 43 , 52 , 63 , 96 , 41 , 173 , 10 , 19 , 40 , 98 , 46 , 202 , 43 , 93 , 63 , 107 , 41 , 84 , 10 ] ) ) . findall ( II1i1Ii11Ii11 )
 if 35 - 35: iiI1i1 + i1IIi11111i + i1IIi11111i
 for I11I11i1I , O00O0O0O0 , url in ii11iIi1I :
  if 'tvg-logo=' in I11I11i1I :
   ii11i1iIII = oooO0oo0oOOOO ( 0 , [ 104 , 207 , 116 , 41 , 116 , 15 , 112 , 102 , 58 , 79 , 47 , 17 , 47 , 184 , 118 , 41 , 100 , 197 , 117 , 28 , 98 , 218 , 116 ] , [ 79 , 50 , 133 , 53 , 140 , 46 , 98 , 120 , 195 , 49 , 216 , 48 , 239 , 104 , 244 , 111 , 123 , 115 , 66 , 116 , 186 , 46 , 76 , 99 , 33 , 111 , 181 , 109 , 31 , 47 , 154 , 76 , 126 , 103 , 115 , 47 ] ) + re . compile ( 'tvg-logo="(.+?)"' ) . findall ( I11I11i1I ) [ 0 ]
   if 3 - 3: OoOoOO00 / oOoO0oo0OOOo % i1 * Ii / o0o00Oo0O * i1
  else :
   ii11i1iIII = ''
   if 49 - 49: iiI1iIiI % Oooo0000 + OoOoOO00 . oOoO0oo0OOOo % i11Ii11I1Ii1i
  if oooo . getSetting ( 'parental' ) == 'true' :
   if not '18' in O00O0O0O0 :
    oo ( O00O0O0O0 , url , 200 , ii11i1iIII , '' )
  else :
   oo ( O00O0O0O0 , url , 200 , ii11i1iIII , '' )
   if 48 - 48: i1 + i1 / i11ii11iIi11i / iI11I1II1I1I
   if 20 - 20: iiI1i1
 OO ( 'movies' , 'default' )
 if 77 - 77: Ii11111i / i1
 if 98 - 98: iI11I1II1I1I / OoOoOO00 / Ii / iiI1i1
 if 28 - 28: ooo0Oo0 - o000o0o00o0Oo . o000o0o00o0Oo + Ii11111i - II111iiii + o0o00Oo0O
 if 95 - 95: Iii1ii1II11i % iiI1iIiI . o0o00Oo0O
 if 15 - 15: i1iIIII / Oooo0000 . Oooo0000 - OoOoOO00
def OoOooOOOO ( url ) :
 if 'pastebin' in url :
  try :
   o00oOO0 = urllib2 . Request ( url )
   o00oOO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
   i1iIIi1 = urllib2 . urlopen ( o00oOO0 )
   O00oooo0O = i1iIIi1 . read ( )
   i1iIIi1 . close ( )
   return O00oooo0O
  except : OoOooOOOO ( url )
 else :
  o00oOO0 = urllib2 . Request ( url )
  o00oOO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
  i1iIIi1 = urllib2 . urlopen ( o00oOO0 )
  O00oooo0O = i1iIIi1 . read ( )
  i1iIIi1 . close ( )
  return O00oooo0O
  if 95 - 95: ooo0Oo0 / II111iiii
  if 18 - 18: Ii
def Ii11I ( url , data = None , headers = None , use_cache = True , cache_limit = 8 ) :
 if 69 - 69: iiI1iIiI % i1iII1I1i1i1 - iiI1i1 + i1iII1I1i1i1 - o0o00Oo0O % II111iiii
 iIiiI1 = ''
 if use_cache :
  Iii111II = iIiiiI1IiI1I1 . get ( 'timestamp_' + url )
  if Iii111II :
   iiii11I = time . time ( ) - float ( Iii111II )
   Ooo0OO0oOO = 06 * 06 * cache_limit
   if iiii11I < Ooo0OO0oOO :
    iIiiI1 = iIiiiI1IiI1I1 . get ( url )
    if iIiiI1 :
     I11i . log_debug ( 'Cache URL data found for: %s' % url )
     return iIiiI1
     if 50 - 50: oOoO0oo0OOOo
 I11i . log ( 'Retrieving: %s' % url )
 if data :
  if headers :
   iIiiI1 = oo000 . http_POST ( url , data , headers = headers ) . content
  else :
   iIiiI1 = oo000 . http_POST ( url , data ) . content
 else :
  if headers :
   iIiiI1 = oo000 . http_GET ( url , headers = headers ) . content
  else :
   iIiiI1 = oo000 . http_GET ( url ) . content
   if 34 - 34: oOoO0oo0OOOo * i11ii11iIi11i % i1IIi11111i * Ii11111i - oOoO0oo0OOOo
 if use_cache :
  iIiiiI1IiI1I1 . set ( url , iIiiI1 )
  iIiiiI1IiI1I1 . set ( 'timestamp_' + url , str ( time . time ( ) ) )
  if 33 - 33: iiI1i1 + ooo0Oo0 * Iii1ii1II11i - IiiI / iiI1iIiI % Oooo0000
 return iIiiI1
 if 21 - 21: Iii1ii1II11i * iI11I1II1I1I % iiI1iIiI * OoOoOO00
def Ii11Ii1I ( html ) :
#embedtext = "(<object type=\"application/x-shockwave-flash\"|<!--[0-9]* start embed [0-9]*-->|<!-- BEGIN PLAYER CODE.+?-->|<!-- Begin PLAYER CODE.+?-->|<!--[ ]*START PLAYER CODE [&ac=270 kayakcon11]*-->|)(.+?)<!-- END PLAYER CODE [A-Za-z0-9]*-->"
 O00oO = "</div>(.+?)<!-- start Ad Code 2 -->"
 if 39 - 39: o000o0o00o0Oo - i11ii11iIi11i * Iii1ii1II11i % iiI1i1 * i11ii11iIi11i % i11ii11iIi11i
 OoOOOOO = re . search ( O00oO , html , re . DOTALL ) . group ( 1 )
 if 33 - 33: i11Ii11I1Ii1i % OoOoOO00
 OoOOOOO = re . sub ( '(?s)<!--.*?-->' , '' , OoOOOOO ) . strip ( )
 return OoOOOOO
 if 78 - 78: i1
def OO00Oo ( name , url , iconimage ) :
 if '.f4m' in url :
  import F4MProxy
  O0OOO0OOoO0O = F4MProxy . f4mProxyHelper ( )
  O0OOO0OOoO0O . playF4mLink ( url , name )
 else :
  if 'pageUrl=' in url :
   url = O00Oo000ooO0 ( url )
  elif 'aliez' in url :
   url = OoO0O00 ( url )
   url = O00Oo000ooO0 ( url )
  elif 'irishtv' in url :
   url = IIiII ( url )
   url = O00Oo000ooO0 ( url )
  elif 'finecast' in url :
   url = o0 ( url )
   url = O00Oo000ooO0 ( url )
  elif 'hdcast' in url :
   url = ooOooo000oOO ( url )
   url = O00Oo000ooO0 ( url )
  elif 'stream4free' in url :
   url = Oo0oOOo ( url )
   url = O00Oo000ooO0 ( url )
  elif 'ibrod' in url :
   url = ibrod ( url )
   url = O00Oo000ooO0 ( url )
  elif 'deltatv' in url :
   url = Oo0OoO00oOO0o ( url )
   url = O00Oo000ooO0 ( url )
  elif 'streamlive' in url :
   url = OOO00O ( url )
   url = O00Oo000ooO0 ( url )
  elif 'vaughnlive' in url :
   url = OOoOO0oo0ooO ( url )
   url = O00Oo000ooO0 ( url )
  elif 'tgun' in url :
   url = OOO00O ( url )
   url = O00Oo000ooO0 ( url )
  elif 'liveall' in url :
   url = O0o0O00Oo0o0 ( url )
   url = O00Oo000ooO0 ( url )
  elif 'privatestream' in url :
   url = O00O0oOO00O00 ( url )
   url = O00Oo000ooO0 ( url )
  elif 'leton' in url :
   url = i1Oo00 ( url )
   url = O00Oo000ooO0 ( url )
  elif 'sawlive' in url :
   url = sawlive ( url , ref_url )
   url = O00Oo000ooO0 ( url )
  elif 'zerocast' in url :
   url = i1i ( url )
   url = O00Oo000ooO0 ( url )
  elif 'thethaohd' in url :
   url = iiI111I1iIiI ( url )
   url = O00Oo000ooO0 ( url )
  else :
   II = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
   II . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
   II . setProperty ( "IsPlayable" , "true" )
   II . setPath ( url )
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II )
   if 45 - 45: o0o00Oo0O * iiI1i1 % IiiI * II111iiii + i1IIi11111i . Ii11111i
def Oo0ooOo0o ( ) :
 Ii1i1 = [ ]
 iiIii = sys . argv [ 2 ]
 if len ( iiIii ) >= 2 :
  ooo0O = sys . argv [ 2 ]
  oOoO0o00OO0 = ooo0O . replace ( '?' , '' )
  if ( ooo0O [ len ( ooo0O ) - 1 ] == '/' ) :
   ooo0O = ooo0O [ 0 : len ( ooo0O ) - 2 ]
  i1I1ii = oOoO0o00OO0 . split ( '&' )
  Ii1i1 = { }
  for oOOo0 in range ( len ( i1I1ii ) ) :
   oo00O00oO = { }
   oo00O00oO = i1I1ii [ oOOo0 ] . split ( '=' )
   if ( len ( oo00O00oO ) ) == 2 :
    Ii1i1 [ oo00O00oO [ 0 ] ] = oo00O00oO [ 1 ]
    if 23 - 23: Iii1ii1II11i + Iii1ii1II11i . ooo0Oo0
 return Ii1i1
 if 38 - 38: i1iII1I1i1i1
def oo ( name , url , mode , iconimage , description ) :
 Ii1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 OOooOO000 = True
 II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 II . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 OOoOoo = [ ]
 if mode == 200 :
  if not '.f4m' in url :
   II . setProperty ( "IsPlayable" , "true" )
   if 85 - 85: i11Ii11I1Ii1i % i1IIi11111i % i1iIIII
  OOooOO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = II , isFolder = False )
 else :
  if 82 - 82: Ii - i1IIi11111i * II111iiii / i1
  xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1 , listitem = II , isFolder = True )
 return OOooOO000
 if 31 - 31: o000o0o00o0Oo . Iii1ii1II11i - iI11I1II1I1I
 if 64 - 64: i1
 if 22 - 22: IiiI + Oooo0000 % i11Ii11I1Ii1i
 if 9 - 9: II111iiii
def OO ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if oooo . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % oooo . getSetting ( viewType ) )
  if 62 - 62: ooo0Oo0 / Iii1ii1II11i + Oooo0000 / Iii1ii1II11i . i11ii11iIi11i
  if 68 - 68: Ii % i11Ii11I1Ii1i + Ii
  if 31 - 31: i11ii11iIi11i . oOoO0oo0OOOo
def O00Oo000ooO0 ( url ) :
 url
 II = xbmcgui . ListItem ( O00O0O0O0 , iconImage = 'DefaultVideo.png' , thumbnailImage = ii11i1iIII )
 II . setInfo ( type = 'Video' , infoLabels = { 'Title' : O00O0O0O0 } )
 II . setProperty ( "IsPlayable" , "true" )
 II . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , II )
def o0 ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( "file: '(.+?)'" ) . findall ( O00oooo0O ) [ 0 ]
 II1I = ii11iIi1I
 return II1I + ' swfUrl=http://www.finecast.tv/player6/jwplayer.flash.swf flashver=WIN\2017,0,0,134 live=1 live=true timeout=14 swfVfy=1 pageUrl=' + url
 if 84 - 84: o000o0o00o0Oo . Ii . o000o0o00o0Oo * i11Ii11I1Ii1i - i1
def Oo0oOOo ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( '<source src="(.+?)"' ) . findall ( O00oooo0O ) [ 0 ]
 return ii11iIi1I + '|User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36'
 if 42 - 42: Ii
def IIiII ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( 'file: "rtmp(.+?)"' ) . findall ( O00oooo0O ) [ 0 ]
 II1I = ii11iIi1I . replace ( 'amp;' , '' )
 return 'rtmp' + II1I + ' live=true live=1 ' + url
 if 33 - 33: i1IIi11111i - o0o00Oo0O * OoOoOO00 * iiI1i1 - IiiI
def iiI111I1iIiI ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( "var channel_stream = '(.+?)';" ) . findall ( O00oooo0O ) [ 0 ]
 II1I = ii11iIi1I
 return II1I
 if 32 - 32: II111iiii / iI11I1II1I1I - iiI1i1
def Oo0OoO00oOO0o ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( 'flashvars="file=(.+?)&.+?streamer=(.+?)&.+? />' ) . findall ( O00oooo0O ) [ 0 ]
 o00oooO0Oo = ii11iIi1I [ 0 ]
 II1I = ii11iIi1I [ 1 ]
 return II1I + ' playpath=' + o00oooO0Oo + ' swfUrl=http://cdn.goodcast.co/players.swf live=true token=Fo5_n0w?U.rA6l3-70w47ch flashver=WIN/2018,0,0,160 timeout=13 swfVfy=1 pageUrl=' + url
 if 78 - 78: Oooo0000 % i1iII1I1i1i1 + i11Ii11I1Ii1i
def OOO00O ( url ) :
 global par
 par = urlparse ( url ) . query
 OOooOoooOoOo = re . search ( "((HTTP|http)://.+)" , par )
 o0OOOO00O0Oo = par . replace ( 'channel=' , '' ) . replace ( 'width=640&height=400&' , '' )
 ii = {
 'Referer' : 'http://www.streamlive.to/' ,
 'Host' : 'www.streamlive.to' ,
 'Origin' : 'www.streamlive.to'
 }
 if 90 - 90: iiI1i1 % OoOoOO00 / Iii1ii1II11i
 if o0OOOO00O0Oo :
  if 44 - 44: IiiI . Iii1ii1II11i / i11Ii11I1Ii1i + Oooo0000
  url = 'http://www.streamlive.to/embedplayer.php?channel=%s' % o0OOOO00O0Oo
  iIiiI1 = Ii11I ( url , headers = ii )
  if 65 - 65: o0o00Oo0O
  oO00OOoO00 = re . compile ( '''.*getJSON\("([^'"]+)".*''' ) . findall ( iIiiI1 ) [ 0 ]
  if not oO00OOoO00 . startswith ( 'http' ) :
   oO00OOoO00 = 'http:' + oO00OOoO00
   if 40 - 40: oOoO0oo0OOOo * Oooo0000 + ooo0Oo0 % i1IIi11111i
  OOOOOoo0 = Ii11I ( oO00OOoO00 , headers = ii )
  ii1 = re . compile ( '{"token":"(.+?)"}' ) . findall ( OOOOOoo0 ) [ 0 ]
  I1iI1iIi111i = re . search ( 'file: "(.+?).flv"' , iIiiI1 ) . group ( 1 )
  II1I = re . search ( 'streamer: "(.+?)",' , iIiiI1 ) . group ( 1 )
  II1I = II1I . replace ( "\\" , "" )
  iiIi1IIi1I = re . search ( 'rtmp://[\.\w:]*/([^\s]+)' , II1I ) . group ( 1 )
 else :
  I1iI1iIi111i = re . search ( 'streamer=rtmp://live.streamlive.to/edge&file=(.+?)&autostart=true&controlbar=bottom"' , embedcode ) . group ( 1 )
  url = 'http://www.streamlive.to/embedplayer.php'
  if 84 - 84: i1iIIII * i11ii11iIi11i + IiiI
 O0ooO0Oo00o = 'http://player.streamlive.to/streamlive-plugin.swf'
 return II1I + ' playPath=' + I1iI1iIi111i + ' swfUrl=' + O0ooO0Oo00o + ' swfVfy=true live=true token=' + ii1 + 'buffer=10000 app=' + iiIi1IIi1I + ' pageUrl=' + url
 if 77 - 77: iI11I1II1I1I * Iii1ii1II11i
def OOoOO0oo0ooO ( url ) :
 global par
 par = urlparse ( url ) . query
 OOooOoooOoOo = re . search ( "((HTTP|http)://.+)" , par )
 o0OOOO00O0Oo = par
 if o0OOOO00O0Oo :
  url = 'http://vaughnlive.tv/embed/video/%s' % o0OOOO00O0Oo
 ii = {
 'Referer' : url , 'Host' : 'vaughnlive.tv'
 }
 try :
  iIiiI1 = Ii11I ( url , headers = ii )
  iIiiI1 = Ii11I ( url , headers = ii )
  oOooOo0 = urlparse ( url ) . netloc
  if 38 - 38: i1iII1I1i1i1
  Ooo00o0Oooo = re . search ( 'swfobject.embedSWF\("(.+?)",' , iIiiI1 ) . group ( 1 )
  print
  OOooooO0Oo = 'live'
  if 'instagib.' in oOooOo0 : OOooooO0Oo = 'instagib'
  elif 'vapers.' in oOooOo0 : OOooooO0Oo = 'vapers'
  elif 'breakers.' in oOooOo0 : OOooooO0Oo = 'breakers'
  print
  OOiIiIIi1 = 'http://mvn.vaughnsoft.net/video/edge/%s_%s' % ( oOooOo0 , par )
  I1IIII1i = Ii11I ( OOiIiIIi1 , use_cache = False )
  I1I11i = re . search ( 'mvnkey-(.+)' , I1IIII1i ) . group ( 1 )
  Ii1I1I1i1Ii = re . search ( '(.+?);' , I1IIII1i ) . group ( 1 )
  i1Oo0oO00o = "rtmp://%s/live App=live?%s Playpath=%s_%s  swfUrl=http://%s%s live=true pageUrl=http://%s/embed/video/%s?viewers=true&watermark=left&autoplay=true" % ( Ii1I1I1i1Ii , I1I11i , OOooooO0Oo , par , oOooOo0 , Ooo00o0Oooo , oOooOo0 , par )
  return i1Oo0oO00o
  if 13 - 13: i1 * IiiI * i1iIIII
 except Exception , IiII1IiiIiI1 :
  I11i . log_error ( 'Failed to resolve Vaughn Live: %s' % IiII1IiiIiI1 )
  return None
  if 50 - 50: iiI1i1 * i1 % o0o00Oo0O
  if 61 - 61: oOoO0oo0OOOo - ooo0Oo0 . iiI1iIiI / ooo0Oo0 + IiiI
def I1i11i ( pattern , link ) :
 if 64 - 64: ooo0Oo0 % iI11I1II1I1I * iiI1iIiI
 return re . compile ( pattern ) . findall ( link ) [ 0 ]
 if 79 - 79: o0o00Oo0O
def O0o0O00Oo0o0 ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 oOO00O = int ( I1i11i ( 'var f = (.+?);' , O00oooo0O ) )
 iII111ii = int ( I1i11i ( 'var a = (.+?);' , O00oooo0O ) )
 OOOoo0OO = int ( I1i11i ( 'var b = (.+?);' , O00oooo0O ) )
 o0oO0 = int ( I1i11i ( 'var c = (.+?);' , O00oooo0O ) )
 oO0o0 = int ( I1i11i ( 'var d = (.+?);' , O00oooo0O ) )
 iI1Ii11iIiI1 = I1i11i ( "var v_part = '(.+?)'" , O00oooo0O )
 iII111ii = iII111ii / oOO00O
 OOOoo0OO = OOOoo0OO / oOO00O
 o0oO0 = o0oO0 / oOO00O
 oO0o0 = oO0o0 / oOO00O
 II1I = 'rtmp://%s.%s.%s.%s%s' % ( iII111ii , OOOoo0OO , o0oO0 , oO0o0 , iI1Ii11iIiI1 )
 return II1I + ' swfUrl=http://wds.liveall.tv/jwplayer.flash.swf live=true live=1 pageUrl=' + url
 if 86 - 86: iiI1iIiI * iiI1i1 % OoOoOO00 . Oooo0000 . Ii
def O00O0oOO00O00 ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 oOO00O = int ( I1i11i ( 'var f = (.+?);' , O00oooo0O ) )
 iII111ii = int ( I1i11i ( 'var a = (.+?);' , O00oooo0O ) )
 OOOoo0OO = int ( I1i11i ( 'var b = (.+?);' , O00oooo0O ) )
 o0oO0 = int ( I1i11i ( 'var c = (.+?);' , O00oooo0O ) )
 oO0o0 = int ( I1i11i ( 'var d = (.+?);' , O00oooo0O ) )
 iI1Ii11iIiI1 = I1i11i ( "var v_part = '(.+?)'" , O00oooo0O )
 iII111ii = iII111ii / oOO00O
 OOOoo0OO = OOOoo0OO / oOO00O
 o0oO0 = o0oO0 / oOO00O
 oO0o0 = oO0o0 / oOO00O
 II1I = 'rtmp://%s.%s.%s.%s%s' % ( iII111ii , OOOoo0OO , o0oO0 , oO0o0 , iI1Ii11iIiI1 )
 return II1I + ' swfUrl=http://privatestream.tv/js/jwplayer.flash.swf live=true live=1 pageUrl=' + url
 if 56 - 56: i11Ii11I1Ii1i % o0o00Oo0O - oOoO0oo0OOOo
def i1Oo00 ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 oOO00O = int ( I1i11i ( 'var f = (.+?);' , O00oooo0O ) )
 iII111ii = int ( I1i11i ( 'var a = (.+?);' , O00oooo0O ) )
 OOOoo0OO = int ( I1i11i ( 'var b = (.+?);' , O00oooo0O ) )
 o0oO0 = int ( I1i11i ( 'var c = (.+?);' , O00oooo0O ) )
 oO0o0 = int ( I1i11i ( 'var d = (.+?);' , O00oooo0O ) )
 iI1Ii11iIiI1 = I1i11i ( "var v_part = '(.+?)'" , O00oooo0O )
 iII111ii = iII111ii / oOO00O
 OOOoo0OO = OOOoo0OO / oOO00O
 o0oO0 = o0oO0 / oOO00O
 oO0o0 = oO0o0 / oOO00O
 II1I = 'rtmp://%s.%s.%s.%s%s' % ( iII111ii , OOOoo0OO , o0oO0 , oO0o0 , iI1Ii11iIiI1 )
 return II1I + ' swfUrl=http://files.leton.tv/jwplayer.flash.swf live=true live=1 pageUrl=' + url
 if 100 - 100: Oooo0000 - o0o00Oo0O % iiI1iIiI * ooo0Oo0 + oOoO0oo0OOOo
def OoO0O00 ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( '"rtmp(.+?)"' ) . findall ( O00oooo0O ) [ 0 ]
 Oo0O0oooo = ii11iIi1I . replace ( '%3A' , ':' ) . replace ( '%2F' , '/' ) . replace ( '%3F' , '?' ) . replace ( '%3D' , '=' )
 return 'rtmp' + Oo0O0oooo + ' live=true swfVfy=1 swfUrl=http://i.aliez.tv/swf/player.swf?7 pageUrl=' + url
 if 33 - 33: i1iII1I1i1i1 + i1IIi11111i * iiI1iIiI / iI11I1II1I1I - oOoO0oo0OOOo
 if 54 - 54: i1iII1I1i1i1 / ooo0Oo0 . iiI1iIiI % i1IIi11111i
def Oo ( url ) :
 O00oooo0O = OoOooOOOO ( url )
 ii11iIi1I = re . compile ( '"flashplayer": "(.+?)" "file": "(.+?)""streamer": "(.+?)"' ) . findall ( O00oooo0O ) [ 0 ]
 return ii11iIi1I + ' swfUrl=http://www.finecast.tv/player6/jwplayer.flash.swf flashver=WIN\2017,0,0,134 live=1 live=true timeout=14 swfVfy=1 pageUrl=' + url
 if 65 - 65: Oooo0000 - iiI1iIiI + iiI1iIiI + i11ii11iIi11i
def i1i ( url ) :
 global par
 par = urlparse ( url ) . query
 OOooOoooOoOo = re . search ( "((HTTP|http)://.+)" , par )
 o0OOOO00O0Oo = par . replace ( 'a=' , '' )
 ii = {
 'Referer' : 'http://zerocast.tv/' ,
 'Host' : 'zerocast.tv' ,
 'Origin' : 'zerocast.tv'
 }
 if o0OOOO00O0Oo :
  url = 'http://zerocast.tv/embed.php?a=%s' % o0OOOO00O0Oo
  iIiiI1 = Ii11I ( url , headers = ii )
  oO00OOoO00 = re . compile ( '''.*getJSON\("([^'"]+)".*''' ) . findall ( iIiiI1 ) [ 0 ]
  if not oO00OOoO00 . startswith ( 'http' ) :
   oO00OOoO00 = 'http:' + oO00OOoO00
   if 96 - 96: ooo0Oo0 % o0o00Oo0O / o0o00Oo0O
  OOOOOoo0 = Ii11I ( oO00OOoO00 , headers = ii )
  ii1 = re . compile ( '{"token":"(.+?)"}' ) . findall ( OOOOOoo0 ) [ 0 ]
  II1I = re . search ( "file: '(.+?)'," , iIiiI1 ) . group ( 1 )
 return II1I + ' swfUrl=http://p.jwpcdn.com/6/12/jwplayer.flash.swf live=1 live=true timeout=15 token=' + ii1 + ' swfVfy=1 pageUrl=' + url
 if 44 - 44: iiI1iIiI / i1 / i1
def ooOooo000oOO ( url ) :
 ii = {
 'Referer' : 'http://hdcast.me/' ,
 'Host' : 'hdcast.me' ,
 'Origin' : 'hdcast.me' ,
 'User-Agent' : "Magic Browser"
 }
 iIiiI1 = Ii11I ( url , headers = ii )
 oO00OOoO00 = re . compile ( '''.getJSON\("([^'"]+)".*''' ) . findall ( iIiiI1 ) [ 0 ]
 if not oO00OOoO00 . startswith ( 'http' ) :
  oO00OOoO00 = 'http:' + oO00OOoO00
  if 87 - 87: IiiI . oOoO0oo0OOOo - i11ii11iIi11i + o0o00Oo0O / IiiI / iiI1iIiI
 OOOOOoo0 = Ii11I ( oO00OOoO00 , headers = ii )
 ii1 = re . compile ( '{"token":"(.+?)"}' ) . findall ( OOOOOoo0 ) [ 0 ]
 II1I = re . search ( "file: 'rtmpe(.+?)'," , iIiiI1 ) . group ( 1 )
 return 'rtmpe' + II1I + ' swfUrl=http://p.jwpcdn.com/6/12/jwplayer.flash.swf live=1 timeout=15 token=' + ii1 + ' live=true swfVfy=1 buffer=100000 pageUrl=' + url
 if 25 - 25: oOoO0oo0OOOo . oOoO0oo0OOOo - Ii11111i % Ii11111i - Ii / i1iII1I1i1i1
 if 51 - 51: IiiI / Ii11111i . ooo0Oo0 * iiI1i1 + Iii1ii1II11i * o000o0o00o0Oo
ooo0O = Oo0ooOo0o ( )
OOOoOo = None
O00O0O0O0 = None
O00o0 = None
ii11i1iIII = None
I11iII = None
if 5 - 5: oOoO0oo0OOOo
if 48 - 48: iiI1i1 - iiI1iIiI / II111iiii
try :
 OOOoOo = urllib . unquote_plus ( ooo0O [ "url" ] )
except :
 pass
try :
 O00O0O0O0 = urllib . unquote_plus ( ooo0O [ "name" ] )
except :
 pass
try :
 ii11i1iIII = urllib . unquote_plus ( ooo0O [ "iconimage" ] )
except :
 pass
try :
 O00o0 = int ( ooo0O [ "mode" ] )
except :
 pass
try :
 I11iII = urllib . unquote_plus ( ooo0O [ "description" ] )
except :
 pass
 if 100 - 100: oOoO0oo0OOOo / iiI1i1 % i11ii11iIi11i % IiiI % ooo0Oo0
print "Mode: " + str ( O00o0 )
print "URL: " + str ( OOOoOo )
print "Name: " + str ( O00O0O0O0 )
print "IconImage: " + str ( ii11i1iIII )
if 98 - 98: i1 % Ii % i1iIIII + Oooo0000
if 78 - 78: i11Ii11I1Ii1i % iiI1iIiI / i1IIi11111i - iI11I1II1I1I
if 69 - 69: i1iII1I1i1i1
if O00o0 == None or OOOoOo == None or len ( OOOoOo ) < 1 :
 print ""
 I1 ( )
 if 11 - 11: oOoO0oo0OOOo
elif O00o0 == 1 :
 print "" + OOOoOo
 IiIiIi ( OOOoOo )
 if 16 - 16: Oooo0000 + o000o0o00o0Oo * o0o00Oo0O % OoOoOO00 . oOoO0oo0OOOo
elif O00o0 == 200 :
 if 67 - 67: II111iiii / oOoO0oo0OOOo * Oooo0000 + i1
 OO00Oo ( O00O0O0O0 , OOOoOo , ii11i1iIII )
 if 65 - 65: II111iiii - i11Ii11I1Ii1i / i1iIIII / i11ii11iIi11i / OoOoOO00
elif O00o0 == 2001 :
 if 71 - 71: i1iII1I1i1i1 + Oooo0000
 playall ( O00O0O0O0 , OOOoOo )
 if 28 - 28: ooo0Oo0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
