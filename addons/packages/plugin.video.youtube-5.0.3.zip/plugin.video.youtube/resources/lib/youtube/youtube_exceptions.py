from resources.lib import kodion

__author__ = 'bromix'


class LoginException(kodion.KodimonException):
    pass


class YouTubeException(kodion.KodimonException):
    pass
