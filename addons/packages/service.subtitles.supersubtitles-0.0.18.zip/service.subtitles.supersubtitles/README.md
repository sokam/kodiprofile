service.subtitles.supersubtitles
================================

Super Subtitles


Based on
 - https://github.com/kispaljr/script.xbmc.subtitles
 - https://github.com/amet/service.subtitles.demo/
 - https://github.com/amet/service.subtitles.opensubtitles
 - https://github.com/amet/service.subtitles.podnapisi
